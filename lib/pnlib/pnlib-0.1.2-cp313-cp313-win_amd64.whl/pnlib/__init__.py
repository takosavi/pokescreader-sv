from .repos import successful


def is_successfully_loaded() -> bool:
    return successful
