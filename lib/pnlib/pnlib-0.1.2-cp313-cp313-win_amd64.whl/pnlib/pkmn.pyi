from typing import Callable, Iterable, Iterator, Optional, TypeAlias
from cv2.typing import MatLike

MapFunc: TypeAlias = Callable[
    [Callable[[MatLike], Optional[tuple[int, int]]], Iterable[int]],
    Iterator[Optional[tuple[int, int]]],
]

def recognize_ally_pokemon_for_selection(
    image: MatLike,
    index: int,
) -> Optional[tuple[int, int]]: ...
def recognize_ally_team_for_selection(
    image: MatLike,
    map_func: Optional[MapFunc] = None,
) -> Iterator[Optional[tuple[int, int]]]: ...
def recognize_ally_pokemon_for_command(
    image: MatLike,
    index: int,
    preferred_ids: Optional[Iterable[int]] = None,
) -> Optional[tuple[int, int]]: ...
def recognize_opponent_pokemon(
    image: MatLike,
    index: int,
) -> Optional[tuple[int, int]]: ...
def recognize_opponent_team(
    image: MatLike,
    map_func: Optional[MapFunc] = None,
) -> Iterator[Optional[tuple[int, int]]]: ...
