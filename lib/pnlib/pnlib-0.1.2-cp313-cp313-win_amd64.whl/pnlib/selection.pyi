from typing import Optional

from cv2.typing import MatLike

def recognize_selection(image: MatLike) -> list[Optional[int]]: ...
